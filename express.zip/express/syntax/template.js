const name = 'gunwoo';
var letter = 'asdlfasdk'+name+'\n\nfjs;dlkfjs;a'+name+'dfjasdlkfjs;sjlkfjsdlkfjasdlkf'; 
console.log(letter);

var letter = `asdlfasdk ${name}

fjs;dlkfjs;a'+name+'dfjasdlkfjs;sjlkfjsdlkfjasdlkf. ${name}`;
console.log(letter);