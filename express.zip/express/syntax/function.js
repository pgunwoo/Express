f123();
console.log('a');
console.log('c');
console.log('d');
f123();
console.log('z');
console.log('s');
console.log('w');
f123();
console.log('e');
console.log('q');
console.log('r');
f123();

function f123() {
    console.log(1);
    console.log(2);
    console.log(3);
    console.log(4);
}