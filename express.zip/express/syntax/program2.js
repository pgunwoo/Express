console.log("A");
console.log("B");
console.log("c2");
console.log("d");