const args = process.argv;
console.log(args[2]);
console.log("A");
console.log("B");
if(args[2] === '1'){
    console.log("c1");
} else {
    console.log("c2");
}
console.log("d");