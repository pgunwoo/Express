console.log("A");
console.log("B");
console.log("c1");
console.log("d");