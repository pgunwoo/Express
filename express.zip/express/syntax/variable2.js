const letter = 'asdlfasdkfjs;dlkfjs;adfjasdlkfjs;sjlkfjsdlkfjasdlkf'; 
console.log(letter);