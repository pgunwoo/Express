console.log(Math.round(1.6));//2
console.log(Math.round(1.4));//1

function sum(num1, num2) { // parameter
    return num1+num2;
}

sum(2,4); //argument

console.log(sum(2,4));